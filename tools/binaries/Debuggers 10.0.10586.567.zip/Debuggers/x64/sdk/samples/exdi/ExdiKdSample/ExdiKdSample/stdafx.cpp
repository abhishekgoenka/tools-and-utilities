//----------------------------------------------------------------------------
//
// stdafx.cpp
//
// This file is used to generate precompiled header files.
//
// Copyright (c) Microsoft. All rights reserved.
//
//----------------------------------------------------------------------------

#include "stdafx.h"
