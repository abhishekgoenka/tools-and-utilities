/*++

Copyright (c) Microsoft Corporation

Module Name:

    kdintel.c

Abstract:

    Intel Network Kernel Debug Support.

Author:

    Joe Ballantyne (joeball)

--*/

#define _INTEL_C
#include "pch.h"
#undef _INTEL_C

#include "intel.c"
